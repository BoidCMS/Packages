<?php defined( 'App' ) or die( 'BoidCMS' );
/**
 *
 * Markdown Editor – Content Formatting Using Markdown Syntax
 *
 * @package Plugin_Markdown_Editor
 * @author Shuaib Yusuf Shuaib
 * @version 0.1.0
 */

if ( 'markdown-editor' !== basename( __DIR__ ) ) return;

global $App;
$App->set_action( 'admin_head', 'mde_style'  );
$App->set_action( 'admin_end',  'mde_script' );
$App->set_action( 'slug_taken', 'mde_slug'   );
$App->set_action( 'render', 'mde_image_ajax' );

/**
 * Editor style
 * @return string
 */
function mde_style(): string {
  global $App;
  if ( ! mde_allowed() ) return '';
  return '
  <link rel="stylesheet" href="' . $App->url( 'plugins/markdown-editor/css/easymde.css' ) . '">
  <style>@media(max-width:600px){.EasyMDEContainer{width:100%!important}}.EasyMDEContainer{width:60%;margin:auto;text-align:left}.EasyMDEContainer .editor-preview-full *{max-width:100%;font-family:initial}</style>';
}

/**
 * Editor script
 * @return string
 */
function mde_script(): string {
  global $App;
  if ( ! mde_allowed() ) return '';
  return '
  <script src="' . $App->url( 'plugins/markdown-editor/js/easymde.js' ) . '"></script>
  <script src="' . $App->url( 'plugins/markdown-editor/js/showdown.js' ) . '"></script>
  <script>const converter=new showdown.Converter();const element=document.querySelector("#content");const easyMDE_option=' . easymde_option() . ';easyMDE_option.element=element;easyMDE_option.initialValue=converter.makeMarkdown(element.value);easyMDE_option.toolbar[14].action=EasyMDE.drawUploadedImage;const easyMDE=new EasyMDE(easyMDE_option);document.querySelector("[type=submit]").onclick=()=>{easyMDE.value(converter.makeHtml(easyMDE.value()));};</script>';
}

/**
 * Taken slug
 * @return string
 */
function mde_slug(): string {
  return ',ajax/markdown-editor,';
}

/**
 * Tells whether editor is needed
 * @return bool
 */
function mde_allowed(): bool {
  global $App, $page;
  $pages = array( 'create', 'update' );
  $pages = $App->_l( 'editable_pages', $pages );
  return in_array( $page, $pages );
}

/**
 * AJAX image upload
 * @return void
 */
function mde_image_ajax(): void {
  global $App;
  if ( 'ajax/markdown-editor' === $App->page ) {
    header( 'Content-Type: application/json' );
    
    $token = $App->esc( $_POST[ 'token' ] ?? '' );
    if ( ! hash_equals( $App->token(), $token ) ) {
      exit( '{"error":"importError"}' );
    }
    
    elseif ( ! isset( $_FILES[ 'image' ] ) ) {
      exit( '{"error":"noFileGiven"}' );
    }
    
    $_FILES[ 'file' ] = $_FILES[ 'image' ];
    unset( $_FILES[ 'image' ] );
    
    $success = $App->upload_media( $msg, $file );
    if ( ! $success ) {
      exit( '{"error":' . json_encode( $msg ) . '}' );
    }
    
    $data = array();
    $data[ 'data' ] = array();
    $data[ 'data' ][ 'filePath' ] = $App->url( 'media/' . $file );
    exit( json_encode( $data ) );
  }
}

/**
 * EasyMDE options
 * @return string
 */
function easymde_option(): string {
  global $App;
  
  $option = array();
  $option[ 'toolbar' ] = array();
  $option[ 'toolbar' ][] = 'bold';
  $option[ 'toolbar' ][] = 'italic';
  $option[ 'toolbar' ][] = 'strikethrough';
  $option[ 'toolbar' ][] = 'heading';
  
  $option[ 'toolbar' ][] =    '|';
  $option[ 'toolbar' ][] = 'code';
  $option[ 'toolbar' ][] = 'quote';
  $option[ 'toolbar' ][] = 'ordered-list';
  $option[ 'toolbar' ][] = 'unordered-list';
  $option[ 'toolbar' ][] = 'table';
  $option[ 'toolbar' ][] = 'horizontal-rule';
  
  $option[ 'toolbar' ][] =    '|';
  $option[ 'toolbar' ][] = 'link';
  $option[ 'toolbar' ][] = 'image';
  $option[ 'toolbar' ][] = array(
    'name' => 'upload-image',
    'className' => 'fa fa-upload',
    'title' => 'Upload Image'
  );
  
  $option[ 'toolbar' ][] =       '|';
  $option[ 'toolbar' ][] = 'preview';
  $option[ 'toolbar' ][] = 'undo';
  $option[ 'toolbar' ][] = 'redo';
  
  $option[ 'toolbar' ][] =            '|';
  $option[ 'toolbar' ][] = 'side-by-side';
  $option[ 'toolbar' ][] = 'fullscreen';
  $option[ 'toolbar' ][] = 'guide';
  
  $option[ 'uploadImage' ] = true;
  $option[ 'imageUploadEndpoint' ] = $App->url( 'ajax/markdown-editor' );
  $option[ 'imageCSRFToken' ] = $App->token();
  $option[ 'imagePathAbsolute' ] = true;
  $option[ 'imageCSRFName' ] = 'token';
  
  $option = $App->get_filter( $option, 'markdown_editor.easymde.options' );
  return json_encode( $option );
}
?>
