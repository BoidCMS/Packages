# CRON
Web-based Task Scheduler

## Install
- Download the zip file of the plugin from this repo.
- Extract the contents of the zip file.
- Create a folder `cron` in the `plugins/` directory on your server.
- Copy the `plugin.php` file to the `cron` folder.
- Follow the [steps to activate and configure](https://boidcms.github.io/#/plugins/configure) the plugin.

## Compatibility
This plugin works on any version of BoidCMS.
