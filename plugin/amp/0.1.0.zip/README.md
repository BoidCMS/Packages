# AMP
AMP Plugin for Lightning-Fast Performance

## Install
- Download the zip file of the plugin from this repo.
- Extract the contents of the zip file.
- Create a folder `amp` in the `plugins/` directory on your server.
- Copy the content of the zip to the `amp` folder.
- Follow the [steps to activate and configure](https://boidcms.github.io/#/plugins/configure) the plugin.

## Compatibility
This plugin works on any version of BoidCMS.
